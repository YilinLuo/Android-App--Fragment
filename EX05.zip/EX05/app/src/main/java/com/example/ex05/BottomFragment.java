package com.example.ex05;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class BottomFragment extends FragmentLifecycleLogger{
    public static TextView display_Msg;

    public BottomFragment() {
        // Required empty public constructor
    }


   public void messageSentBack(CharSequence message){
        if(message != null)
           display_Msg.setText(message.toString());
        Log.d(TAG,"THE STRING IS "+ message);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_bottom, container, false);
        display_Msg = (TextView)v.findViewById(R.id.bottomF_textview);
        return v;
    }

}
