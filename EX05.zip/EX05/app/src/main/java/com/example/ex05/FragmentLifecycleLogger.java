package com.example.ex05;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;

public class FragmentLifecycleLogger extends Fragment {

    /* Since the other fragment classes extend this class-
    this TAG will let log show the class and method name.
    */

    protected final String TAG = getClass().getName();


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        Log.d(TAG, "OnAttach is called. ");
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "OnCreate is called. ");
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.d(TAG, "OnActivityCreated is called. ");
    }


    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "OnStart is called. ");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "OnResume is called. ");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "OnPause is called. ");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "OnStop is called. ");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.d(TAG, "OnDestroyView is called. ");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "OnDestroy is called. ");
    }
}
