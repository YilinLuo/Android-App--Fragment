package com.example.ex05;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements TopFragment.OnFragmentInteractionListener{
    private EditText main_editText;
    private Button send_Msg_button;
    private String inputText;
    public String sendBack;
    protected final String TAG = getClass().getName();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        main_editText = findViewById(R.id.main_editText);
        send_Msg_button = findViewById(R.id.main_button);

       FragmentManager fm = getSupportFragmentManager();
        TopFragment fragment_top = new TopFragment();
        BottomFragment fragment_bottom = new BottomFragment();
            fm.beginTransaction()
                    .add(R.id.xml_fragment_top, fragment_top)
                    .commit();

            fm.beginTransaction()
                    .add(R.id.xml_fragment_bottom, fragment_bottom)
                    .commit();

        main_editText.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after){

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int count, int after) {
                inputText = s.toString();
                send_Msg_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(inputText != null)
                        {TopFragment.newInstance(inputText);
                        Log.d(TAG,inputText);
                        }

                    }


                });
            }
            @Override
            public void afterTextChanged(Editable s){

            }
                });

    }

    @Override
    public void onFragmentInteractionListener(String sendBack){
        BottomFragment bottomUpdate = (BottomFragment)getSupportFragmentManager().findFragmentById(R.id.xml_fragment_bottom);
        bottomUpdate.messageSentBack(sendBack);
    }



}
