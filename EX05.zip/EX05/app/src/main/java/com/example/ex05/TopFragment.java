package com.example.ex05;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class TopFragment extends FragmentLifecycleLogger{
    private OnFragmentInteractionListener tListener;
    public static EditText received_msg;
    public static Button send_back;
    public static TextView onDisplay;
    protected static final String TAG = "in top fragment";

    public static final String ARG_INPUT_TEXT = "input_text";

    //Bundle for top fragment.
    public static TopFragment newInstance(String s){
        Bundle args = new Bundle();
        args.putString(ARG_INPUT_TEXT, s);
        received_msg.setText(s);
        onDisplay.setText(s);
        TopFragment fragment = new TopFragment();
        fragment.setArguments(args);
        Log.d(TAG,s +"in bundle");
        return fragment;
    }

    public TopFragment() {
        // Required empty public constructor
    }

    public void onSendBackPressed(String sendBack){
        if (tListener != null){
            tListener.onFragmentInteractionListener(sendBack);
        }
    }

    @Override
    public void onAttach(Context context){
        super.onAttach(context);
        try{
            tListener =(OnFragmentInteractionListener) context;
        }catch(ClassCastException e){
            throw new ClassCastException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_top, container, false);

        onDisplay = (TextView)v.findViewById(R.id.TopF_textview);
        received_msg = (EditText) v.findViewById(R.id.TopF_editText);
        send_back = (Button)v.findViewById(R.id.sendBack);

        Bundle toDisplay = getArguments();
        if(toDisplay != null) {
            received_msg.setText(toDisplay.getString(ARG_INPUT_TEXT));
            onDisplay.setText(toDisplay.getString(ARG_INPUT_TEXT));
            Log.d(TAG,toDisplay.getString(ARG_INPUT_TEXT));
        }

       send_back.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               onSendBackPressed(received_msg.getText().toString());
           }
       });

        return v;
    }

    public interface OnFragmentInteractionListener{
        public void onFragmentInteractionListener (String sendBack);
    }

}
